# books Shop

This project is about a shopping cart made with react js.

It was mainly thought to upload it to my youtube channel and show how to build a simple shopping cart step by step to all those people who are starting with the React Js framework, focusing on showing how react-router-dom and context work.

You can see the youtube video here : [on the code YouTube](https://www.youtube.com/watch?v=uPYfPcMtOvI)
